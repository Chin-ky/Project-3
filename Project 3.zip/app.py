import os
import io
import pandas as pd
import numpy as np


from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from tensorflow.keras.utils import to_categorical
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import pickle

from flask import Flask, request, redirect, url_for, jsonify, render_template

app = Flask(__name__)

model = None

# Loading a random classifier model with flask
def load_model():

    load_model()

def predictor(to_predict_list): 
	to_predict = np.array(to_predict_list).reshape(1, 6)
	loaded_model = pickle.load(open("finalized_model.pkl", "rb")) 
	result = loaded_model.predict(to_predict) 
	return result[0] 


@app.route('/', methods = ['GET', 'POST']) 
def result(): 
    if request.method == 'POST': 
        to_predict_list = request.form.to_dict() 
        to_predict_list = list(to_predict_list.values()) 
        to_predict_list = list(map(int, to_predict_list)) 
        prediction = predictor(to_predict_list)     

        return render_template("result.html", prediction=prediction) 
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)

